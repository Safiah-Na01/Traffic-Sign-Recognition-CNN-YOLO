"""Integrated traffic-sign recognition: YOLO detection -> crop -> CNN classification."""
import time
import numpy as np
import cv2
import tensorflow as tf
import torch
from ultralytics import YOLO


def sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


class TrafficSignRecognizer:
    def __init__(self, yolo_path, cnn_path, imgsz=640, conf=0.25, crop_pad=0.10,
                 cnn_size=64, device=0 if torch.cuda.is_available() else "cpu"):
        self.yolo = YOLO(str(yolo_path))
        self.cnn = tf.keras.models.load_model(str(cnn_path))
        self.imgsz, self.conf, self.crop_pad = imgsz, conf, crop_pad
        self.cnn_size, self.device = cnn_size, device
        self.names = {int(k): v for k, v in self.yolo.names.items()}
        n_cnn = int(self.cnn.output_shape[-1])
        if sorted(self.names) != list(range(n_cnn)):
            raise ValueError(f"Class mismatch: YOLO has {len(self.names)} classes, CNN outputs {n_cnn}")

    # ---- stage 1: detection ----
    def detect(self, sources, batch=64):
        """sources: list of image paths or BGR ndarrays."""
        return self.yolo.predict(source=sources, imgsz=self.imgsz, conf=self.conf,
                                 device=self.device, batch=batch, verbose=False)

    # ---- stage 2: crop ----
    def crop(self, img_bgr, box):
        h, w = img_bgr.shape[:2]
        x1, y1, x2, y2 = [float(v) for v in box]
        px, py = (x2 - x1) * self.crop_pad, (y2 - y1) * self.crop_pad
        x1 = int(min(max(0, np.floor(x1 - px)), w - 1))
        y1 = int(min(max(0, np.floor(y1 - py)), h - 1))
        x2 = int(min(w, max(np.ceil(x2 + px), x1 + 1)))
        y2 = int(min(h, max(np.ceil(y2 + py), y1 + 1)))
        return cv2.cvtColor(img_bgr[y1:y2, x1:x2], cv2.COLOR_BGR2RGB)

    # ---- stage 3: classification ----
    def preprocess(self, crops_rgb):
        out = [tf.cast(tf.image.resize(c, (self.cnn_size, self.cnn_size)), tf.float32) / 255.0
               for c in crops_rgb]
        return tf.stack(out)

    def classify(self, crops_rgb):
        if len(crops_rgb) == 0:
            return np.empty(0, dtype=int), np.empty(0, dtype=float)
        probs = self.cnn(self.preprocess(crops_rgb), training=False).numpy()
        return probs.argmax(axis=1), probs.max(axis=1)

    # ---- detections -> crops -> CNN labels (batched over all crops) ----
    def process_results(self, results, timing=None):
        per_image, crops, owners = [], [], []
        t0 = time.perf_counter()
        for r in results:
            dets = []
            if r.boxes is not None and len(r.boxes) > 0:
                xyxy = r.boxes.xyxy.cpu().numpy()
                conf = r.boxes.conf.cpu().numpy()
                cls = r.boxes.cls.cpu().numpy().astype(int)
                for j in np.argsort(-conf):                      # highest confidence first
                    dets.append({"box": tuple(float(v) for v in xyxy[j]),
                                 "det_conf": float(conf[j]), "yolo_cls": int(cls[j])})
                    crops.append(self.crop(r.orig_img, xyxy[j]))
                    owners.append((len(per_image), len(dets) - 1))
            per_image.append(dets)
        t1 = time.perf_counter()
        cnn_cls, cnn_conf = self.classify(crops)
        t2 = time.perf_counter()
        for (i, j), c, p in zip(owners, cnn_cls, cnn_conf):
            per_image[i][j]["cnn_cls"], per_image[i][j]["cnn_conf"] = int(c), float(p)
        for dets in per_image:
            for d in dets:
                d["yolo_name"] = self.names[d["yolo_cls"]]
                d["final_cls"] = d["cnn_cls"]                    # final label = CNN label
                d["final_name"] = self.names[d["final_cls"]]
        if timing is not None:
            timing["crop_ms"] = (t1 - t0) * 1e3
            timing["cnn_ms"] = (t2 - t1) * 1e3                   # preprocess + CNN inference
        return per_image

    def predict_image(self, image, timing=False):
        """image: path or BGR ndarray -> list of detections (+ timing dict if requested)."""
        t = {}
        sync(); a = time.perf_counter()
        results = self.detect([image], batch=1)
        sync(); b = time.perf_counter()
        dets = self.process_results(results, timing=t)[0]
        t["yolo_ms"] = (b - a) * 1e3
        t["total_ms"] = t["yolo_ms"] + t["crop_ms"] + t["cnn_ms"]
        return (dets, t) if timing else dets
